# Symfony

This plugin provides native completion for [Symfony](https://symfony.com/), but requires at least Symfony 6.2.

To use it add `symfony6` to the plugins array in your zshrc file.

```bash
plugins=(... symfony6)
```
