## Fossil Plugin

This plugin adds completion support and prompt for fossil repositories.
The prompt will display the current branch and status been dirty or clean.

### CONTRIBUTOR
 - Jefferson González ([jgmdev](https://github.com/jgmdev))
